package me.superischroma.spectaculation.entity;

public interface JockeyStatistics extends EntityStatistics
{
    SEntityType getPassenger();
}