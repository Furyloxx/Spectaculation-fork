package me.superischroma.spectaculation.entity.insentient;

public class WheatCrystal extends FloatingCrystal
{
    @Override
    protected String getURL()
    {
        return "d7d30431c2945ced873c27575eeaac22adb28adac7fbd89b56eb9e93979ce0fd";
    }
}