package me.superischroma.spectaculation.entity.nms;

import java.util.UUID;

public interface SlayerBoss
{
    UUID getSpawnerUUID();
}