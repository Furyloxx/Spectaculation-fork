package me.superischroma.spectaculation.item;

public enum ItemOrigin
{
    NATURAL_BLOCK,
    CRAFTING,
    MOB,
    UNKNOWN
}