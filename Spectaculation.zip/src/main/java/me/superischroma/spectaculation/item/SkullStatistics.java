package me.superischroma.spectaculation.item;

public interface SkullStatistics extends MaterialStatistics
{
    String getURL();
}