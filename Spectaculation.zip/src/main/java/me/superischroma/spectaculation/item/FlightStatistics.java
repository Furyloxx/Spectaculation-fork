package me.superischroma.spectaculation.item;

public interface FlightStatistics extends MaterialStatistics
{
    boolean enableFlight();
}