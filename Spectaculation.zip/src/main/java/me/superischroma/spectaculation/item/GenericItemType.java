package me.superischroma.spectaculation.item;

public enum GenericItemType
{
    WEAPON,
    TOOL,
    RANGED_WEAPON,
    ARMOR,
    ACCESSORY,
    BLOCK,
    ITEM,
    PET,
    ENCHANTMENT
}