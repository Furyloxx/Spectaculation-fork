package me.superischroma.spectaculation.gui;

import org.bukkit.Material;

public interface BlockBasedGUI
{
    Material getBlock();
}