# Skyblock Remake Project (WIP)

A fork of the Spectaculation Hypixel SkyBlock plugin, originally coded by Super, has been enhanced and modified.

# Supported Server Version : 1.8.8

## Features :

- Auction System
- Accessory System
- Crafting
- Crystals
- Collections
- Custom Drops
- Custom Enchantments
- Island System
- Item System
- Skills
- Spawners
- Slayers
- Mobs
- Regions
- Reforges
- pets
- Economy
- Mining

## Coming soon
- Merchants
- NPCS
- Bazaar


## Commands :
- /ib
- /spawnspec <name>
- /coins <add , remove , set> <value>
- /specreforge <name>
- /ah
- /visit <name>
- /specenchantment <name> <level>
- /is
- /entityspawner [create <type> | delete <index>]
- /hub
- /recom
- /region [create <name> <type> | update <name> [type] | delete <name>]
- /spot

## Installation
- Download the latest release from the Releases section.
- Place the plugin JAR file in your server's plugins  folder.
- Restart the server.
## Discord : devil_gamer_xd
