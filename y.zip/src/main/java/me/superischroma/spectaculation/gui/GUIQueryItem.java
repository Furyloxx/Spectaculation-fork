package me.superischroma.spectaculation.gui;

public interface GUIQueryItem extends GUIClickableItem
{
    GUI onQueryFinish(String query);
}