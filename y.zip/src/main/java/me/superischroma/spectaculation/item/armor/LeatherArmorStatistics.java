package me.superischroma.spectaculation.item.armor;

import me.superischroma.spectaculation.item.ToolStatistics;

public interface LeatherArmorStatistics extends ToolStatistics
{
    int getColor();
}
