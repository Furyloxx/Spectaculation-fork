package me.superischroma.spectaculation.item;

public enum AbilityActivation
{
    RIGHT_CLICK,
    LEFT_CLICK,
    FLIGHT,
    SHOOT,
    NO_ACTIVATION
}