package me.superischroma.spectaculation.item.revenant;

import me.superischroma.spectaculation.item.GenericItemType;
import me.superischroma.spectaculation.item.MaterialFunction;
import me.superischroma.spectaculation.item.MaterialStatistics;
import me.superischroma.spectaculation.item.Rarity;

public class FoulFlesh implements MaterialStatistics, MaterialFunction
{
    @Override
    public String getDisplayName()
    {
        return "Foul Flesh";
    }

    @Override
    public Rarity getRarity()
    {
        return Rarity.RARE;
    }

    @Override
    public GenericItemType getType()
    {
        return GenericItemType.ITEM;
    }
}