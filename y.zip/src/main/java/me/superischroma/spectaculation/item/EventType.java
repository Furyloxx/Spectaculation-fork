package me.superischroma.spectaculation.item;

public enum EventType
{
    KILL,
    DEATH
}