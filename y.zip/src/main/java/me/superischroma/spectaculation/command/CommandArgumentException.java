package me.superischroma.spectaculation.command;

public class CommandArgumentException extends RuntimeException
{
    public CommandArgumentException()
    {
        super("");
    }
}