# Supported Server Version : 1.8.8

## Features :

- Auction System
- Accessory System
- Crafting
- Crystals
- Collections
- Custom Drops
- Custom Enchantments
- Island System
- Item System
- Skills
- Spawners
- Slayers
- Mobs
- Regions
- Reforges
- pets
- Economy
- Mining without regeneration system 😗

## Commands :
- `/ib`

- `/spawn <name>`

- `/coins <add , remove , set> <value>`

- `/ref <name>`

- `/ah`

- `/visit <name>`

- `/ench <name> <level>`

- `/is`

- `/entityspawner [create <type> | delete <index>]`

- `/hub`

- `/recom`

- `/region [create <name> <type> | update <name> [type] | delete <name>]`

- `/spot`